"""
插件管理处理器

处理Blender插件管理命令。
"""

from typing import Any, Dict
import bpy
import addon_utils


def handle_list(params: Dict[str, Any]) -> Dict[str, Any]:
    """列出所有插件"""
    try:
        addons = []
        
        for mod in addon_utils.modules():
            name = mod.__name__
            bl_info = getattr(mod, "bl_info", {})
            
            # 检查是否启用
            is_enabled = addon_utils.check(name)[0]
            
            addons.append({
                "name": name,
                "bl_name": bl_info.get("name", name),
                "version": bl_info.get("version", (0, 0, 0)),
                "author": bl_info.get("author", "Unknown"),
                "description": bl_info.get("description", ""),
                "category": bl_info.get("category", ""),
                "enabled": is_enabled
            })
        
        return {
            "success": True,
            "data": {
                "addons": addons,
                "total": len(addons)
            }
        }
    
    except Exception as e:
        return {
            "success": False,
            "error": {"code": "LIST_ERROR", "message": str(e)}
        }


def handle_enable(params: Dict[str, Any]) -> Dict[str, Any]:
    """启用插件"""
    addon_name = params.get("addon_name")
    
    try:
        bpy.ops.preferences.addon_enable(module=addon_name)
        
        return {
            "success": True,
            "data": {
                "addon_name": addon_name,
                "enabled": True
            }
        }
    
    except Exception as e:
        return {
            "success": False,
            "error": {"code": "ENABLE_ERROR", "message": str(e)}
        }


def handle_disable(params: Dict[str, Any]) -> Dict[str, Any]:
    """禁用插件"""
    addon_name = params.get("addon_name")
    
    try:
        bpy.ops.preferences.addon_disable(module=addon_name)
        
        return {
            "success": True,
            "data": {
                "addon_name": addon_name,
                "enabled": False
            }
        }
    
    except Exception as e:
        return {
            "success": False,
            "error": {"code": "DISABLE_ERROR", "message": str(e)}
        }


def handle_install(params: Dict[str, Any]) -> Dict[str, Any]:
    """安装插件"""
    filepath = params.get("filepath")
    overwrite = params.get("overwrite", True)
    enable = params.get("enable", True)
    
    try:
        bpy.ops.preferences.addon_install(
            filepath=filepath,
            overwrite=overwrite
        )
        
        # 获取安装的插件名称
        import os
        addon_name = os.path.splitext(os.path.basename(filepath))[0]
        
        if enable:
            bpy.ops.preferences.addon_enable(module=addon_name)
        
        return {
            "success": True,
            "data": {
                "addon_name": addon_name,
                "installed": True,
                "enabled": enable
            }
        }
    
    except Exception as e:
        return {
            "success": False,
            "error": {"code": "INSTALL_ERROR", "message": str(e)}
        }


def handle_info(params: Dict[str, Any]) -> Dict[str, Any]:
    """获取插件详细信息"""
    addon_name = params.get("addon_name")
    
    try:
        for mod in addon_utils.modules():
            if mod.__name__ == addon_name:
                bl_info = getattr(mod, "bl_info", {})
                is_enabled = addon_utils.check(addon_name)[0]
                
                return {
                    "success": True,
                    "data": {
                        "name": addon_name,
                        "bl_name": bl_info.get("name", addon_name),
                        "version": bl_info.get("version", (0, 0, 0)),
                        "blender": bl_info.get("blender", (0, 0, 0)),
                        "author": bl_info.get("author", "Unknown"),
                        "description": bl_info.get("description", ""),
                        "location": bl_info.get("location", ""),
                        "warning": bl_info.get("warning", ""),
                        "doc_url": bl_info.get("doc_url", ""),
                        "tracker_url": bl_info.get("tracker_url", ""),
                        "support": bl_info.get("support", ""),
                        "category": bl_info.get("category", ""),
                        "enabled": is_enabled
                    }
                }
        
        return {
            "success": False,
            "error": {"code": "NOT_FOUND", "message": f"插件不存在: {addon_name}"}
        }
    
    except Exception as e:
        return {
            "success": False,
            "error": {"code": "INFO_ERROR", "message": str(e)}
        }
